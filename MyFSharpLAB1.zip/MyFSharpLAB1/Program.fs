﻿let applyExponent (exponent: int) (value: float) : float = 
    value ** float exponent
let square = applyExponent 2
let cube = applyExponent 3

let resultSquare = square 4.0
let resultCube = cube 4.0      


printfn "Square of 4: %f" resultSquare  
printfn "Cube of 4: %f " resultCube    
printfn("\n")


let rec productOfListTailRec (list: int list) (acc: int) : int =
    match list with
    | [] -> acc  
    | head :: tail -> productOfListTailRec tail (acc * head)  


let numbersList = [1; 2; 3; 4; 5]

let resultProduct = productOfListTailRec numbersList 1  


printfn "Product of the list: %d \n" resultProduct  


let rec productOfOddNumbersTailRec (n: int) (acc: int) : int =
    if n <= 0 then
        acc  
    else
        productOfOddNumbersTailRec (n - 2) (acc * n)  


let resultOddProduct = productOfOddNumbersTailRec 11 1  

printfn "Product of odd numbers from 11: %d \n" resultOddProduct  


let names = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let trimmedNames = List.map (fun (name: string) -> name.Trim()) names


printfn "Trimmed names: %A" trimmedNames  
printfn("\n")


let numbers = Seq.init 700 (fun i -> i + 1) |> Seq.toList
let filteredNumbers = List.filter (fun (n: int) -> n % 5 = 0 && n % 7 = 0) numbers
let sumOfFilteredNumbers = List.fold (+) 0 filteredNumbers


printfn "Sum of filtered numbers: %d" sumOfFilteredNumbers 
printfn("\n")



let namesList: string list = ["Pushpa"; "Mandeep"; "Ikka"; "Dushyant"; ""; "Imraan"; "Singh"]

let filteredNames = List.filter (fun (name: string) -> name.ToLower().Contains("i")) namesList


let concatenatedNames = List.reduce (+) filteredNames


printfn "Concatenated Names: %s" concatenatedNames