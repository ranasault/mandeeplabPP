using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace aspnetcoreapp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            // Initialization or default view
        }

        public void OnPost()
        {
            if (Request.Form["num1"].Count > 0 && Request.Form["num2"].Count > 0)
            {
                // Parse the numbers from the form input
                double num1 = double.Parse(Request.Form["num1"]);
                double num2 = double.Parse(Request.Form["num2"]);

                // Check which operation was selected
                string operation = Request.Form["operation"];
                double result = 0;
                string errorMessage = "";

                switch (operation)
                {
                    case "ADD":
                        result = num1 + num2;
                        break;

                    case "SUBTRACT":
                        result = num1 - num2;
                        break;

                    case "MULTIPLY":
                        result = num1 * num2;
                        break;

                    case "DIVIDE":
                        if (num2 != 0)
                        {
                            result = num1 / num2;
                        }
                        else
                        {
                            errorMessage = "Cannot divide by zero!";
                        }
                        break;

                    case "SQUARE ROOT":
                        if (num1 >= 0)
                        {
                            result = Math.Sqrt(num1); // Only take sqrt of num1
                        }
                        else
                        {
                            errorMessage = "Cannot take square root of a negative number!";
                        }
                        break;

                    case "POWER":
                        result = Math.Pow(num1, num2); // num1 raised to the power of num2
                        break;

                    default:
                        errorMessage = "Invalid operation.";
                        break;
                }

                // Store result or error message in ViewData
                if (string.IsNullOrEmpty(errorMessage))
                {
                    ViewData["result"] = "Result: " + result.ToString();
                }
                else
                {
                    ViewData["result"] = errorMessage;
                }
            }
        }
    }
}
